package com.applanga.android;

import android.app.Activity;
import android.content.Context;

import android.os.Bundle;
import android.view.MotionEvent;
import android.webkit.WebView;

import androidx.annotation.NonNull;

import org.jetbrains.annotations.Nullable;

import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

/**
 * Applanga
 */
@SuppressWarnings("unused")
public final class Applanga {
    public enum PluralRule {
        Zero,
        One,
        Two,
        Few,
        Many,
        Other
    }
    
    private Applanga() {
    }
    
    
    /**
     * Call this method before using any other method from the Applanga SDK. This goes e.g. into
     * onCreate of your Application. This configures the Applanga SDK.
     * <pre>
     * {@code
     *  Applanga.init(this);
     * }
     * </pre>
     *
     * @param context The context of your application. You should pass your application instance.
     */
    public static void init(Context context) {
        ALInternal.getInstance().init(context);
    }
    
    
    /**
     * Call this method to get a translation for a string based on the current locale.
     * <pre>
     * {@code
     *  Applanga.getTranslation("APPLANGA_KEY");
     * }
     * </pre>
     *
     * @param key the Applanga Translation key you want to have localized
     * @return returns the current translation for this key.
     * If the key has no translation it falls back to local resources.
     * If there is no string locally with that key it returns null.
     */
    public static @Nullable String getTranslation(String key) {
        return ALInternal.getInstance().getTranslation(key);
    }
    
    
    /**
     * Call this method to get a translation for a string based on the specified language.
     * No fallback languages will be used.
     * @param key the Applanga Translation key you want to have localized
     * @param language the language code in ISO format (e.g. "de", "en-US")
     * @return returns the current translation for this key.
     */
    public static @Nullable String getTranslationForLanguage(String key, String language) {
        return ALInternal.getInstance().getTranslationForLanguage(key, language);
    }
    
    /**
     * Call this method to get a translation for a string based on the current locale.
     * <pre>
     * {@code
     *  Applanga.getTranslation("APPLANGA_KEY", arg1, arg2);
     * }
     * </pre>
     *
     * @param key        the Applanga Translation key you want to have localized
     * @param formatArgs format arguments
     * @return returns the current translation for this key.
     * If the key has no translation it falls back to local resources.
     * If there is no string locally with that key it returns null.
     */
    public static @Nullable String getTranslation(String key, Object... formatArgs) {
        return ALInternal.getInstance().getTranslation(key, formatArgs);
    }
    
    /**
     * Call this method to get a translation for a string based on the specified language.
     * No fallback languages will be used.
     * @param key the Applanga Translation key you want to have localized
     * @param language the language code in ISO format (e.g. "de", "en-US")
     * @param formatArgs format arguments
     * @return returns the current translation for this key.
     */
    public static @Nullable String getTranslationForLanguage(String key, String language, Object... formatArgs) {
        return ALInternal.getInstance().getTranslationForLanguage(key, language, formatArgs);
    }
    
    /**
     * Call this method to get a translation for a string based on the current locale and quantity.
     * <pre>
     * {@code
     *  Applanga.getQuantityTranslation("APPLANGA_KEY", 2);
     * }
     * </pre>
     *
     * @param key   the Applanga Translation key you want to have localized
     * @param count the quantity for which the pluralized string should be found
     * @return returns the current translation for this key.
     * If the key has no translation it falls back to local resources.
     * If there is no string locally with that key it returns null.
     */
    public static @Nullable String getQuantityTranslation(String key, int count) {
        return ALInternal.getInstance().getQuantityTranslation(key, count);
    }
    
    /**
     * Call this method to get a translation for a string based on the specified language.
     * No fallback languages will be used.
     * @param key the Applanga Translation key you want to have localized
     * @param count the quantity for which the pluralized string should be found
     * @param language the language code in ISO format (e.g. "de", "en-US")
     * @return returns the current translation for this key.
     */
    public static @Nullable String getQuantityTranslationForLanguage(String key, int count, String language) {
        return ALInternal.getInstance().getQuantityTranslationForLanguage(key, count, language);
    }
    
    /**
     * Call this method to get a translation for a string based on the current locale and quantity.
     * <pre>
     * {@code
     *  Applanga.getQuantityTranslation("APPLANGA_KEY", 2);
     * }
     * </pre>
     *
     * @param key   the Applanga Translation key you want to have localized
     * @param count the quantity for which the pluralized string should be found
     * @return returns the current translation for this key.
     * If the key has no translation it falls back to local resources.
     * If there is no string locally with that key it returns null.
     */
    public static @Nullable String getQuantityTranslation(String key, int count, Object... formatArgs) {
        return ALInternal.getInstance().getQuantityTranslation(key, count, formatArgs);
    }
    
    /**
     * Call this method to get a translation for a string based on the specified language.
     * No fallback languages will be used.
     * @param key the Applanga Translation key you want to have localized
     * @param count the quantity for which the pluralized string should be found
     * @param language the language code in ISO format (e.g. "de", "en-US")
     * @param formatArgs format arguments
     * @return returns the current translation for this key.
     */
    public static @Nullable String getQuantityTranslationForLanguage(String key, int count, String language, Object... formatArgs) {
        return ALInternal.getInstance().getQuantityTranslationForLanguage(key, count, language, formatArgs);
    }
    
    /**
     * Call this method to get a translation for a string array based on the current locale.
     * <pre>
     * {@code
     *  Applanga.getTranslationArray("APPLANGA_KEY");
     * }
     * </pre>
     *
     * @param key the Applanga Translation key you want to have localized
     * @return returns the current translation array for this key.
     * If the key has no translation it falls back to local resources.
     * If there is no string array locally with that key it returns null.
     */
    public static @Nullable String[] getTranslationArray(String key) {
        return ALInternal.getInstance().getTranslationArray(key);
    }
    
    /**
     * Call this method to get a translation array for a string based on the specified language.
     * No fallback languages will be used.
     * @param key the Applanga Translation key you want to have localized
     * @param language the language code in ISO format (e.g. "de", "en-US")
     * @return returns the current translation for this key.
     */
    public static @Nullable String[] getTranslationArrayForLanguage(String key, String language) {
        return ALInternal.getInstance().getTranslationArrayForLanguage(key, language);
    }
    
    /**
     * Call this method to get a translation for a string based on the current locale.
     * <pre>
     * {@code
     *  Applanga.getString("APPLANGA_KEY", "DEFAULT_VALUE);
     * }
     * </pre>
     *
     * @param id           the Applanga Translation ID you want to have localized
     * @param defaultValue the defaultValue, which will be returned if no translation is found,
     *                     it will also be supplied to the dashboard in case of a missing string upload
     * @deprecated use {@link #getTranslation(String)}
     */
    @Deprecated()
    public static String getString(String id, String defaultValue) {
        return ALInternal.getInstance().getAlGetStringUtils().getStringByKey(null, id, defaultValue);
    }
    
    /**
     * Call this method to get a translation for a resource id based on the current locale. Accepts an android string resource id.
     * <pre>
     * {@code
     *  Applanga.getString(R.string.applanga_string_key, "DEFAULT_VALUE");
     * }
     * </pre>
     *
     * @param id           an android string resource id for a string that you want to have localized
     * @param defaultValue the defaultValue, which will be returned if no translation is found,
     *                     it will also be supplied to the dashboard in case of a missing string upload
     * @deprecated use {@link android.content.res.Resources#getString(int)}
     */
    @Deprecated
    public static String getString(int id, String defaultValue) {
        return ALInternal.getInstance().getAlGetStringUtils().getStringById(null, id, defaultValue);
    }
    
    /**
     * Get localized string for given key and arguments.
     *
     * @param id           the Applanga Translation ID you want to have localized
     * @param defaultValue the defaultValue, which will be returned if no translation is found,
     *                     it will also be supplied to the dashboard in case of a missing string upload
     * @param formatArgs   optional arguments to be inserted into the localized string
     * @return localized string
     * @deprecated use {@link #getTranslation(String, Object...)}
     */
    @Deprecated
    public static String getString(String id, String defaultValue, Object... formatArgs) {
        return ALInternal.getInstance().getAlGetStringUtils().getStringByKey(null, id, defaultValue, formatArgs);
    }
    
    /**
     * Get localized string for given key and arguments. Accepts an android string resource id.
     *
     * @param id           an android string resource id for a string that you want to have localized
     * @param defaultValue the defaultValue, which will be returned if no translation is found,
     *                     it will also be supplied to the dashboard in case of a missing string upload
     * @param formatArgs   optional arguments to be inserted into the localized string
     * @return localized string
     * @deprecated use {@link android.content.res.Resources#getString(int, Object...)} )}
     */
    @Deprecated
    public static String getString(int id, String defaultValue, Object... formatArgs) {
        return ALInternal.getInstance().getAlGetStringUtils().getStringById(null, id, defaultValue, formatArgs);
    }
    
    /**
     * Change Language to new Language specified by language (e.g. 'de') and fetch latest localisation updates from Applanga and apply them to the current activity.
     * <pre>
     * <code></code>
     *  Applanga.setLanguageAndUpdate("de", new ApplangaCallback() {
     *      {@literal @}Override
     *      public void onLocalizeFinished(boolean success) {
     *      }
     *  });
     * </code>
     * </pre>
     *
     * @param language the language you want to change to
     * @param callback The callback that gets called if localisations are updated.
     */
    public static void setLanguageAndUpdate(String language, ApplangaCallback callback) {
        boolean result = setLanguage(language);
        if (result) {
            update(callback);
        } else {
            callback.onLocalizeFinished(false);
        }
    }
    
    /**
     * manually fetch latest localisation updates from Applanga and apply them to the current activity.
     * <pre>
     * <code></code>
     *  Applanga.update(new ApplangaCallback() {
     *      {@literal @}Override
     *      public void onLocalizeFinished(boolean success) {
     *      }
     *  });
     * </code>
     * </pre>
     *
     * @param callback The callback that gets called if localisations are updated
     */
    public static void update(ApplangaCallback callback) {
        ALInternal.getInstance().update(null, null, callback);
    }
    
    /**
     * manually fetch latest localisation updates from Applanga and apply them to the current activity, allowing you to specify the groups and languages
     * to be updated. Equal to updateGroups
     *
     * @param groups    a list of Strings that describe the groups to be updated, pass null to use default groups
     * @param languages a list of Strings that describe the languages to be updated in ISO format, pass null to use default languages
     * @param callback  The callback that gets called if localisations are updated
     */
    public static void update(List<String> groups, List<String> languages, ApplangaCallback callback) {
        ALInternal.getInstance().update(groups, languages, callback);
    }
    
    /**
     * Format is e.g.:
     * {@code
     * HashMap<String, String> keysEn = new HashMap<String, String>();
     * keysEn.put("hello_world", "Hello World!");
     * HashMap<String, String> keysEs = new HashMap<String, String>();
     * keysEn.put("hello_world", "Hola Mundo!");
     * HashMap<String, HashMap<String, String>> translationMap = new HashMap<String, HashMap<String, String>>();
     * translationMap.put("en", keysEn);
     * translationMap.put("es", keysEn);
     * localizeMap(translationMap);
     * }
     *
     * @param map with strings that should be localized
     * @return map with localized strings
     */
    public static HashMap<String, HashMap<String, String>> localizeMap(HashMap<String, HashMap<String, String>> map) {
        return localizeMap(map, true);
    }
    
    /**
     * Format is e.g.:
     * {@code
     * HashMap<String, String> keysEn = new HashMap<String, String>();
     * keysEn.put("hello_world", "Hello World!");
     * HashMap<String, String> keysEs = new HashMap<String, String>();
     * keysEn.put("hello_world", "Hola Mundo!");
     * HashMap<String, HashMap<String, String>> translationMap = new HashMap<String, HashMap<String, String>>();
     * translationMap.put("en", keysEn);
     * translationMap.put("es", keysEn);
     * localizeMap(translationMap);
     * }
     *
     * @param map                  with strings that should be localized
     * @param updateMissingStrings if this is set to true all contained strings from map that are
     *                             not located in the applanga project yet will be uploaded, false
     *                             otherwise
     * @return map with localized strings
     */
    public static HashMap<String, HashMap<String, String>> localizeMap(HashMap<String, HashMap<String, String>> map,
                                                                       boolean updateMissingStrings) {
        return ALInternal.getInstance().getAlGetStringUtils().localizeMap(map, updateMissingStrings);
    }
    
    /**
     * Get all localized strings for given languages. It will return a map with the language code
     * as key and a map with the localized strings as value. It does not calculate any fallbacks,
     * similar to `localizeMap`.
     * So if a string id and translation does exist in e.g. the base language "en" but not in
     * "en-US" and the languages list contains "en-US" the resulting map will be empty, as the
     * strings are not located in the that language but in "en".
     *
     * @param languages asking for string ids and it their translations for a specific language
     * @return returns  a map with the language code as key and a map with the localized strings as value
     *                  similar to `localizeMap()`
     */
    @NonNull
    public static Map<String, Map<String, String>> localizedStringsForLanguages(List<String> languages) {
        return ALInternal.getInstance().getAlGetStringUtils().localizedStringsForLanguages(languages);
    }
    
    /**
     * Only required on API level 10 and only if you are using Applanga.setLanguage().
     * Syncs the device locale and Applanga language settings. Necessary under some circumstances (Api level 10) to make sure the locale used for the app is the one
     * set by Applanga.setLanguage(). Should be called in Application.onConfigurationChanged() after the superclass call. The ApplangaApplication class does this automatically.
     *
     * @deprecated this method should not be used nor be necessary anymore
     */
    @Deprecated
    public static void updateLocaleSettings() {
        ALInternal.getInstance().updateLocaleSettings();
    }
    
    /**
     * Change Language to new Language specified by language (e.g. 'de'). This will set the language that Applanga uses and try to set the corresponding locale for the App.
     * The new language will be saved by default, and used for any subsequent app launches, to disable default persistence set ApplangaPersistentSetLanguage to false, in the AndroidManifest.xml
     *
     * @param language the language you want to change to
     * @return true if language was changed
     */
    public static boolean setLanguage(String language) {
        try {
            return ALInternal.getInstance().setLanguage(language);
        } catch (ALDatabaseNotInitialisedException e) {
            ALLog.warn("Applanga is not initialised yet. Applanga.setLanguage has failed.");
            return false;
        }
    }
    
    /**
     * Change Language to new Language specified by language (e.g. 'de'). This will set the language that Applanga uses and try to set the corresponding locale for the App.
     *
     * @param language   the language you want to change to
     * @param persistent when true, the new language will be saved, and used for any subsequent app launches
     * @return true if language was changed
     */
    public static boolean setLanguage(String language, boolean persistent) {
        try {
            return ALInternal.getInstance().setLanguage(language, persistent);
        } catch (ALDatabaseNotInitialisedException e) {
            ALLog.warn("Applanga is not initialised yet. Applanga.setLanguage has failed.");
            return false;
        }
    }
    
    /**
     * Get pluralisation rule for current language and given quantity based on:
     * http://unicode.org/repos/cldr-tmp/trunk/diff/supplemental/language_plural_rules.html
     */
    @Deprecated
    public static Applanga.PluralRule getPluralRuleForQuantity(int quantity) {
        return ALInternal.getInstance().getPluralRuleForQuantity(quantity);
    }
    
    /**
     * Captures the screenshot and uploads it to the applanga servers with the supplied screen tag.
     * Applanga will automatically try to detect all translated texts that are on the screen and will add them to the screen tag.
     *
     * @param screenTag   Screen tag used to identify the screen.
     * @param applangaIDs Applanga Ids, which you want to be added to the screen tag.
     */
    public static void captureScreenshot(String screenTag, List<String> applangaIDs) {
        ALInternal.getInstance().captureScreenshot(screenTag, applangaIDs, false, null);
    }
    
    /**
     * Captures the screenshot and uploads it to the applanga servers with the supplied screen tag.
     * Applanga will automatically try to detect all translated texts that are on the screen and will add them to the screen tag.
     *
     * @param screenTag   Screen tag used to identify the screen.
     * @param applangaIDs Applanga Ids, which you want to be added to the screen tag.
     * @param enableOcr   Enable OCR screen reading on the applanga backend.
     */
    public static void captureScreenshot(String screenTag, List<String> applangaIDs, boolean enableOcr) {
        ALInternal.getInstance().captureScreenshot(screenTag, applangaIDs, enableOcr, null);
    }
    
    /**
     * Captures the screenshot and uploads it to the applanga servers with the supplied screen tag.
     * Applanga will automatically try to detect all translated texts that are on the screen and will add them to the screen tag.
     *
     * @param screenTag   Screen tag used to identify the screen.
     * @param applangaIDs Applanga Ids, which you want to be added to the screen tag.
     * @param callback    the callback to be executed after the function has finished, will be supplied with a boolean, indication success or failure
     */
    public static void captureScreenshot(String screenTag, List<String> applangaIDs, ScreenshotCallback<Boolean> callback) {
        ALInternal.getInstance().captureScreenshot(screenTag, applangaIDs, false, callback);
    }
    
    /**
     * Captures the screenshot and uploads it to the applanga servers with the supplied screen tag.
     * Applanga will automatically try to detect all translated texts that are on the screen and will add them to the screen tag.
     *
     * @param screenTag   Screen tag used to identify the screen.
     * @param applangaIDs Applanga Ids, which you want to be added to the screen tag.
     * @param callback    the callback to be executed after the function has finished, will be supplied with a boolean, indication success or failure
     * @param enableOcr   Enable OCR screen reading on the applanga backend.
     */
    public static void captureScreenshot(String screenTag, List<String> applangaIDs, boolean enableOcr, ScreenshotCallback<Boolean> callback) {
        ALInternal.getInstance().captureScreenshot(screenTag, applangaIDs, enableOcr, callback);
    }
    
    /**
     * Shows or hides the draft mode menu. Can only be used if the draft mode is active.
     * <p>
     * /**
     * Captures the screenshot and uploads it to the applanga servers with the supplied screen tag.
     * Applanga will automatically try to detect all translated texts that are on the screen and will add them to the screen tag.
     *
     * @param screenTag   Screen tag used to identify the screen.
     * @param applangaIDs Applanga Ids, which you want to be added to the screen tag.
     * @param stringPos   Information about the strings and their positions
     * @param callback    the callback to be executed after the function has finished, will be supplied with a boolean, indication success or failure
     */
    public static void captureScreenshot(String screenTag, List<String> applangaIDs, String stringPos, ScreenshotCallback<Boolean> callback) {
        ALInternal.getInstance().captureScreenshotWithPositions(screenTag, applangaIDs, stringPos, callback);
    }
    
    /**
     * @param visible If set to true show menu, otherwise hide it.
     * @return true if draft menu visible was set as requested, otherwise false
     */
    public static boolean setScreenShotMenuVisible(Boolean visible) {
        return ALInternal.getInstance().setScreenShotMenuVisible(visible);
    }
    
    /**
     * Hands the touch events to the Applanga SDK for switching on/off the Draft Mode. It does not consume the event.
     * Call your event handling code afterwards. This is only necessary if you want to be able to switch Draft Mode on and off
     * through the Applanga SDK's dialog. If you don't need this functionality, you don't need to call this method.
     *
     * @param event    The touch events of your activity.
     * @param activity Activity in which to present the Draft Mode dialog.
     */
    public static void dispatchTouchEvent(MotionEvent event, Activity activity) {
        ALInternal.getInstance().dispatchTouchEvent(event, activity);
    }
    
    /**
     * Get current sdk version.
     */
    @NonNull
    public static String sdkVersion() {
        return BuildConfig.VERSION_NAME;
    }
    
    /**
     * Get Applanga's tag id from name
     *
     * @param tagName Applanga tag name
     * @return Applanga's tag id
     */
    public static int getTag(String tagName) {
        return ALInternal.getInstance().getTag(tagName);
    }
    
    /**
     * Shows the draft mode dialog
     *
     * @param activity Activity on which the dialog appears
     */
    public static void showDraftModeDialog(Activity activity) {
        ALInternal.getInstance().showDraftModeDialog(activity);
    }
    
    /**
     * To be able to fetch last Applanga log lines for debugging purposes
     *
     * @return a string with latest Applanga log lines
     */
    public static String getLogCache() {
        return ALInternal.getLogCache();
    }
    
    /**
     * @param webView WebView which will be attached
     */
    public static void attachWebView(WebView webView) {
        ALInternal.getInstance().attachWebview(webView);
    }
    
    /**
     * Disable or Enable draft mode
     *
     * @param enabled Enable draft mode activation
     */
    public static void setDraftModeEnabled(boolean enabled) {
        ALInternal.getInstance().setDraftModeEnabled(enabled);
    }
    
    /**
     * Disable or Enable show id mode
     * <p>
     * If show id mode is enabled, the applanga sdk returns the key of each string
     * not the value it self. I can be useful for variety of cases,
     * primarily for screenshots. To see an direct effect on your UI you have
     * to reload all your strings. E.g. restart your activity.
     *
     * @param enabled Enable show id mode activation
     */
    public static void setShowIdModeEnabled(boolean enabled) {
        ALInternal.getInstance().setInShowIdMode(enabled);
    }
    
    /**
     * Returns the branch id given by the Applanga settings file.
     *
     * @return the branch id defined in Applanga's settings file. Returns null if branching is not enabled.
     */
    public static @Nullable String getSettingsFileBranchId() {
        return ALInternal.getInstance().getSettingsFileBranchId();
    }
    
    public static void forwardIntentBundle(Bundle bundle) {
        ALInternal.getInstance().forwardIntentBundle(bundle);
    }
    
    /* Returns all the available language configured on the dashboard for the current project.
     * The values in the array will be the iso language code.
     */
    public static @Nullable List<String> getAvailableLanguages() {
        return ALInternal.getInstance().getAvailableLanguages();
    }
}
